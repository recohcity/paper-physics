# sketch2sim 自动化门禁验证报告 v2

**日期**：2026-10-09
**脚本**：`skill/sketch2sim/scripts/audit-case.mjs`
**变更**：N1-N5 整改后重跑

---

## 总览

| 案例 | 退出码 | 失败 | 警告 | 状态 |
|---|---|---|---|---|
| cases/newton-cradle | 0 | 0 | 4 | ✅ PASS |
| cases/trebuchet | 0 | 0 | 0 | ✅ PASS |

---

## 本轮新增检查项（N1-N3）

| 检查项 | 牛顿摆 | 投石机 |
|---|---|---|
| verify.mjs import 运行时 spec.js | ✅ | ✅ |
| intake 数字行数 ≤ verify intake.match 次数 | ✅ 4/4 | ✅ 5/5 |
| resolveParams() 返回运行时实际值 | ✅ L/g/ballR/nBalls/restitution | ✅ ballKg/arm/restAngle |
| 硬编码重复检测：physics 文件 FAIL | ✅ mechanism.js 无 FAIL | ✅ physics/trebuchet.js 无 FAIL |
| 硬编码重复检测：视觉文件 WARN | ✅ 4 条 | ✅ 0 条 |

---

## 警告项（不阻断）

**牛顿摆（4 条）**：audio.js 0.15, environment.js 0.55/0.12, main.js 0.12/0.15, textures.js 0.55
——均为视觉/UI 参数，与 spec 数值巧合，非物理漂移。

**投石机（0 条）**。

---

## N1-N5 整改对照

| 要求 | 状态 | 证据 |
|---|---|---|
| N1: resolveParams() 纯函数，verify 断言运行时 | ✅ | mechanism.js 导出 resolveParams()，返回 L/g/ballR/nBalls/restitution；physics.js 导出 ballKg/arm/restAngle |
| N2: intake 计数 + verify 必须读 spec.js | ✅ | audit 新增两条硬检查：verify import spec.js、intake 数字行数 ≤ match 次数 |
| N3: 重复检测分级+去噪 | ✅ | physics 文件 FAIL、视觉 WARN；跳过注释；白名单 friction/restitution/damping |
| N4: 案例清理 | ✅ | mechanism.js roughness 改读 SPEC.materials；physics.js ballKg 改读 SPEC；stale 注释更新 |
| N5: 杠杆比推导 | ⏭️ 延后 | leverRatio=4.0 为声明值，几何推导需确认 apexX=枢轴位置，留待下一案例验证 |

---

## 链路达标状态

| 链路 | 状态 |
|---|---|
| ① intake → spec.json → spec.js | ✅ 达标（变异测试：改 spec.json 配重下限，verify 报错） |
| ② spec → 运行时代码 | ✅ 达标（resolveParams() 被 verify 断言；硬编码重复检测扫 physics 文件） |

---

## 结论

**两个案例均通过机械门禁，退出码 0。** spec.json 为唯一数据源，verify.mjs import 运行时 spec.js 并调用 resolveParams() 断言实际物理值。intake 每个数字答案都有对应断言。剩余 4 条警告为视觉参数巧合，不影响物理正确性。
